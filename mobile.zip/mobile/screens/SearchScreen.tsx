import React, { useState } from "react";
import {
  ScrollView,
  Text,
  TextInput,
  TouchableOpacity,
  View,
  StyleSheet,
} from "react-native";
import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";

type SearchTheme = {
  surface: string;
  border: string;
  text: string;
  secondaryText: string;
  accent: string;
};

type RecipeItem = {
  _id: string;
  name: string;
  category: string;
  ingredients: string[];
};

type Props<T extends RecipeItem> = {
  theme: SearchTheme;
  ingredientsInput: string;
  onIngredientsChange: (text: string) => void;
  recipes: T[];
  renderRecipeList: (list: T[], scrollEnabled?: boolean) => React.ReactNode;
};

const categories = ["All", "Veg", "Non-Veg", "Breakfast", "Lunch", "Dinner"];

export default function SearchScreen<T extends RecipeItem>({
  theme,
  ingredientsInput,
  onIngredientsChange,
  recipes,
  renderRecipeList,
}: Props<T>) {
  const [selectedCategory, setSelectedCategory] = useState("All");

  const handleClear = () => {
    onIngredientsChange("");
  };

  const handleIngredientPress = (ingredient: string) => {
    const current = ingredientsInput.trim();

    if (!current) {
      onIngredientsChange(ingredient.toLowerCase());
      return;
    }

    const existing = current
      .split(",")
      .map((item) => item.trim().toLowerCase());

    if (existing.includes(ingredient.toLowerCase())) {
      return;
    }

    onIngredientsChange(`${current}, ${ingredient.toLowerCase()}`);
  };

  const filteredRecipes = recipes.filter((recipe) => {
    const category = recipe.category.toLowerCase();
    const name = recipe.name.toLowerCase();

    if (selectedCategory === "All") {
      return true;
    }

    if (selectedCategory === "Veg") {
      return category.includes("vegetarian") || category.includes("vegan");
    }

    if (selectedCategory === "Non-Veg") {
      return [
        "beef",
        "chicken",
        "lamb",
        "pork",
        "seafood",
        "fish",
        "mutton",
        "turkey",
        "duck",
      ].some((word) => category.includes(word));
    }

    return (
      category.includes(selectedCategory.toLowerCase()) ||
      name.includes(selectedCategory.toLowerCase())
    );
  });

  return (
    <View style={styles.container}>
      {/* Sticky section: stays at the top */}
      <View style={styles.stickyHeader}>
        <Text style={[styles.title, { color: theme.text }]}>
          Find your next meal
        </Text>

        <Text style={[styles.subtitle, { color: theme.secondaryText }]}>
          Search recipes using ingredients you have.
        </Text>

        <View
          style={[
            styles.searchBox,
            {
              backgroundColor: theme.surface,
              borderColor: theme.border,
            },
          ]}
        >
          <MaterialCommunityIcons
            name="magnify"
            size={23}
            color={theme.secondaryText}
          />

          <TextInput
            style={[styles.input, { color: theme.text }]}
            placeholder="Tomato, onion, potato..."
            placeholderTextColor={theme.secondaryText}
            selectionColor={theme.accent}
            value={ingredientsInput}
            onChangeText={onIngredientsChange}
            autoCapitalize="none"
            returnKeyType="search"
          />

          {ingredientsInput.length > 0 && (
            <TouchableOpacity
              onPress={handleClear}
              accessibilityLabel="Clear search"
            >
              <MaterialCommunityIcons
                name="close-circle"
                size={21}
                color={theme.secondaryText}
              />
            </TouchableOpacity>
          )}
        </View>
      </View>

      {/* Everything below the search bar scrolls */}
      <ScrollView
        style={styles.scrollArea}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: theme.text }]}>
            Popular ingredients
          </Text>

          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.chipsContainer}
          >
            {["Tomato", "Onion", "Paneer", "Chicken", "Potato"].map(
              (ingredient) => (
                <TouchableOpacity
                  key={ingredient}
                  style={[
                    styles.chip,
                    {
                      backgroundColor: theme.surface,
                      borderColor: theme.border,
                    },
                  ]}
                  onPress={() => handleIngredientPress(ingredient)}
                >
                  <Text style={[styles.chipText, { color: theme.text }]}>
                    {ingredient}
                  </Text>
                </TouchableOpacity>
              ),
            )}
          </ScrollView>
        </View>

        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: theme.text }]}>
            Categories
          </Text>

          <View style={styles.categoryContainer}>
            {categories.map((category) => {
              const selected = selectedCategory === category;

              return (
                <TouchableOpacity
                  key={category}
                  style={[
                    styles.categoryChip,
                    {
                      backgroundColor: selected ? theme.accent : theme.surface,
                      borderColor: theme.border,
                    },
                  ]}
                  onPress={() => setSelectedCategory(category)}
                >
                  <Text
                    style={[
                      styles.categoryText,
                      {
                        color: selected ? "#FFFFFF" : theme.text,
                      },
                    ]}
                  >
                    {category}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </View>
        </View>

        <View style={styles.resultsHeader}>
          <Text style={[styles.sectionTitle, { color: theme.text }]}>
            Recipes
          </Text>

          <Text style={[styles.resultCount, { color: theme.secondaryText }]}>
            {filteredRecipes.length} found
          </Text>
        </View>

        <View style={styles.recipeResults}>
          {renderRecipeList(filteredRecipes, false)}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  stickyHeader: {
    paddingHorizontal: 18,
    paddingTop: 16,
    paddingBottom: 14,
  },
  title: {
    fontSize: 26,
    fontWeight: "800",
    letterSpacing: -0.5,
  },
  subtitle: {
    fontSize: 14,
    marginTop: 5,
    marginBottom: 16,
  },
  searchBox: {
    minHeight: 54,
    borderWidth: 1,
    borderRadius: 17,
    paddingHorizontal: 14,
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  input: {
    flex: 1,
    fontSize: 15,
    paddingVertical: 12,
  },
  scrollArea: {
    flex: 1,
  },
  section: {
    marginTop: 18,
    paddingHorizontal: 18,
  },
  sectionTitle: {
    fontSize: 17,
    fontWeight: "700",
  },
  chipsContainer: {
    gap: 9,
    paddingTop: 12,
    paddingBottom: 4,
  },
  chip: {
    borderWidth: 1,
    borderRadius: 22,
    paddingHorizontal: 15,
    paddingVertical: 9,
  },
  chipText: {
    fontSize: 13,
    fontWeight: "600",
  },
  categoryContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 9,
    marginTop: 12,
  },
  categoryChip: {
    borderWidth: 1,
    borderRadius: 20,
    paddingHorizontal: 14,
    paddingVertical: 9,
  },
  categoryText: {
    fontSize: 13,
    fontWeight: "600",
  },
  resultsHeader: {
    marginTop: 24,
    marginBottom: 14,
    paddingHorizontal: 18,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  resultCount: {
    fontSize: 13,
  },
  recipeResults: {
    paddingHorizontal: 18,
    paddingBottom: 24,
  },
});
